import React, { createContext, useContext, useState } from "react";
import { sanitizeString } from "../utils/sanitize";

export interface LeadData {
  spaceType?: string;
  roomSize?: string;
  fullName?: string;
  emailAddress: string;
  mobileNumber?: string;
  companyName?: string;
  preferredContact?: "Call" | "Email" | "WhatsApp";
  message?: string;
}

interface LeadContextType {
  submitLead: (leadType: string, leadData: LeadData) => boolean;
  getLeads: () => any[];
}

const LeadContext = createContext<LeadContextType | undefined>(undefined);

export function LeadProvider({ children }: { children: React.ReactNode }) {
  const sanitizeLeadData = (data: any): any => {
    if (!data) return data;
    const sanitized: any = {};
    for (const key of Object.keys(data)) {
      if (typeof data[key] === "string") {
        sanitized[key] = sanitizeString(data[key]);
      } else if (typeof data[key] === "object" && data[key] !== null) {
        sanitized[key] = sanitizeLeadData(data[key]);
      } else {
        sanitized[key] = data[key];
      }
    }
    return sanitized;
  };

  const submitLead = (leadType: string, leadData: LeadData): boolean => {
    try {
      const sanitizedDetails = sanitizeLeadData(leadData);
      const existingLeads = localStorage.getItem("av_impact_leads");
      const leads = existingLeads ? JSON.parse(existingLeads) : [];
      leads.push({
        type: leadType,
        data: sanitizedDetails,
        id: Date.now(),
        timestamp: new Date().toISOString()
      });
      localStorage.setItem("av_impact_leads", JSON.stringify(leads));
      return true;
    } catch (e) {
      console.error("Error saving lead in context:", e);
      return false;
    }
  };

  const getLeads = (): any[] => {
    try {
      const existingLeads = localStorage.getItem("av_impact_leads");
      return existingLeads ? JSON.parse(existingLeads) : [];
    } catch (e) {
      console.error("Error getting leads:", e);
      return [];
    }
  };

  return (
    <LeadContext.Provider value={{ submitLead, getLeads }}>
      {children}
    </LeadContext.Provider>
  );
}

export function useLeadContext() {
  const context = useContext(LeadContext);
  if (context === undefined) {
    throw new Error("useLeadContext must be used within a LeadProvider");
  }
  return context;
}
